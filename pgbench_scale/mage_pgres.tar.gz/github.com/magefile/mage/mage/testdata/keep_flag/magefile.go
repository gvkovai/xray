// +build mage

package main

func Noop() {}
